
import * as React from 'react';
import Firstpage from './first_p/First_page';
import {
  BrowserRouter,
  Routes,
  Route } from "react-router-dom";


function App() {
  return (
    <>
    <BrowserRouter>
    <Routes>
      <Route path="" element={ <>  <Firstpage /> </>} />
      <Route path="/Home" element={<></>} />
    </Routes>
    </BrowserRouter>
    </>
  );
}
  
export default App;