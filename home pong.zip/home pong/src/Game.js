import React from 'react'
import Pong from './Pong'

export default function Game() {
  return(
    <div class="container">
    <div class="qrcode">
      <Pong />
    </div>
  </div>
  );
}
